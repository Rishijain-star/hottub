@php
$rawImgs = $it->images;
if ($rawImgs instanceof \Illuminate\Support\Collection) {
    $rawImgs = $rawImgs->all();
}
$imgs = is_array($rawImgs) ? $rawImgs : (is_string($rawImgs) ? (json_decode($rawImgs, true) ?: []) : []);
$imgs = array_values(array_filter(array_map(function ($v) {
    if (is_string($v)) return $v;
    if (is_array($v)) return $v['path'] ?? $v['url'] ?? $v['file'] ?? ($v[0] ?? null);
    return null;
}, $imgs), fn ($v) => is_string($v) && $v !== ''));
$img = count($imgs)
    ? (\App\Support\PublicMedia::url($imgs[0]) ?: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&q=80&auto=format&fit=crop')
    : 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&q=80&auto=format&fit=crop';
@endphp
<div class="ht-card" data-brand="{{ strtolower($it->brand) }}">
    <a class="ht-card__img" href="{{ route('outdoor-products.detail', $it->slug) }}">
        <img src="{{ $img }}" alt="{{ $it->model }}" loading="lazy">
    </a>
    <div class="ht-card__body">
        <div class="ht-card__top">
            <span class="ht-card__brand">{{ $it->brand }}</span>
            @if($it->tier)
            <span class="ht-card__tier ht-card__tier--{{ strtolower(str_replace(' ','-',$it->tier)) }}">{{ strtoupper($it->tier) }}</span>
            @endif
        </div>
        <h3 class="ht-card__name">
            <a href="{{ route('outdoor-products.detail', $it->slug) }}" style="color:inherit;text-decoration:none">{{ $it->model }}</a>
        </h3>
        @include('components.card-description', ['text' => $it->description, 'lines' => 3, 'class' => 'ht-card__desc'])
        <div class="ht-card__specs">
            <span class="ht-card__spec">{{ $it->product_type }}</span>
            @if($it->dimensions)
            <span class="ht-card__spec">{{ $it->dimensions }}</span>
            @endif
        </div>
        <div class="ht-card__rating">
            <span class="ht-stars">★★★★★</span>
            <span class="ht-rating-num">{{ $it->overall ?? '—' }}</span>
        </div>
        <a class="ht-quote-btn" href="{{ route('outdoor-products.detail', $it->slug) }}">View Details</a>
    </div>
</div>
