<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('leads', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->string('phone')->nullable();
            $table->string('postcode');
            $table->json('interests')->nullable(); // hot_tub, swim_spa, etc
            $table->string('timeframe')->nullable(); // immediate, 1-3 months, etc
            $table->text('message')->nullable();
            $table->enum('status', ['new','contacted','converted','closed'])->default('new');
            $table->unsignedBigInteger('assigned_dealer_id')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leads');
    }
};

